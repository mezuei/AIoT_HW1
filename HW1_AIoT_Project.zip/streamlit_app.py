"""
streamlit_app.py
-----------------
Streamlit dashboard — reads from aiotdb.db (sensors table) and
displays dynamic temperature & humidity charts that auto-refresh
every 2 seconds.

Run with:
  streamlit run streamlit_app.py
"""

import sqlite3
import pandas as pd
import streamlit as st
import time

DB_PATH = "aiotdb.db"
REFRESH_INTERVAL = 2          # seconds between auto-refresh
MAX_DISPLAY_ROWS  = 50        # how many latest rows to plot


# ─── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AIoT Sensor Dashboard",
    page_icon="🌡️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* Dark-ish accent colours */
  [data-testid="stMetricValue"] { font-size: 2rem; }
  .block-container { padding-top: 1.5rem; }
  h1 { font-size: 1.9rem !important; }
</style>
""", unsafe_allow_html=True)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_data() -> pd.DataFrame:
    """Load the latest MAX_DISPLAY_ROWS rows from the sensors table."""
    try:
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query(
            f"""
            SELECT id, temperature, humidity, time
            FROM   sensors
            ORDER  BY id DESC
            LIMIT  {MAX_DISPLAY_ROWS}
            """,
            conn,
            parse_dates=["time"],
        )
        conn.close()
        return df.sort_values("id")          # oldest → newest for the chart
    except Exception as e:
        st.error(f"DB error: {e}  →  Make sure sensor_generator.py is running first.")
        return pd.DataFrame()


# ─── Layout ──────────────────────────────────────────────────────────────────

st.title("🌡️ AIoT Sensor Dashboard — DHT11 Simulation")
st.caption(f"SQLite3 · `aiotdb.db` · sensors table · auto-refresh every {REFRESH_INTERVAL}s")

# Metric cards placeholder
col1, col2, col3, col4 = st.columns(4)
temp_metric = col1.empty()
hum_metric  = col2.empty()
count_metric = col3.empty()
status_box  = col4.empty()

st.divider()

# Chart placeholders
chart_col1, chart_col2 = st.columns(2)
with chart_col1:
    st.subheader("🌡️ Temperature (°C)")
    temp_chart = st.empty()
with chart_col2:
    st.subheader("💧 Humidity (%RH)")
    hum_chart = st.empty()

st.divider()
st.subheader("📋 Latest Readings")
table_box = st.empty()


# ─── Auto-refresh loop ────────────────────────────────────────────────────────

while True:
    df = load_data()

    if df.empty:
        status_box.warning("⚠️ No data yet — start sensor_generator.py")
    else:
        latest = df.iloc[-1]

        # Metric cards
        temp_metric.metric("Latest Temp",     f"{latest['temperature']:.1f} °C")
        hum_metric.metric( "Latest Humidity", f"{latest['humidity']:.1f} %RH")
        count_metric.metric("Total Records",  len(df))
        status_box.success("🟢 Live")

        # Temperature line chart
        temp_chart.line_chart(
            df.set_index("time")[["temperature"]],
            color=["#ff6b6b"],
            use_container_width=True,
        )

        # Humidity line chart
        hum_chart.line_chart(
            df.set_index("time")[["humidity"]],
            color=["#4ecdc4"],
            use_container_width=True,
        )

        # Table (newest first)
        display_df = (
            df[["id", "temperature", "humidity", "time"]]
            .sort_values("id", ascending=False)
            .reset_index(drop=True)
        )
        display_df.columns = ["ID", "Temperature (°C)", "Humidity (%RH)", "Timestamp"]
        table_box.dataframe(display_df, use_container_width=True, hide_index=True)

    time.sleep(REFRESH_INTERVAL)
    st.rerun()
